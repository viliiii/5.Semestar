package hr.fer.oprpp1.custom.scripting.lexer;

public enum LexerState {
    TAG,
    TEXT
}
