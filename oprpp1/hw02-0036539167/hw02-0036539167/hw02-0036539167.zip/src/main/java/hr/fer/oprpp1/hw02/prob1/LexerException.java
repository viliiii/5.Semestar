package hr.fer.oprpp1.hw02.prob1;

public class LexerException extends RuntimeException{
    public LexerException(){
        super();
    }

    public LexerException(String message){
        super(message);
    }
}
